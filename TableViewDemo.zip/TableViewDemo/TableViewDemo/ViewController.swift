//
//  ViewController.swift
//  TableViewDemo
//
//  Created by Kota,Manoj on 4/25/22.
//

import UIKit
class Product{
    var productName : String?
    var productCategory: String?
     
    init(productName : String,productDescription : String){
        self.productName = productName
        self.productCategory = productDescription
    }
}
class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    var productArray = [Product]()
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return productArray.count
    }
    
   
    
    
    @IBOutlet weak var TableViewOutlet: UITableView!
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = TableViewOutlet.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
        cell.textLabel?.text=productArray[indexPath.row].productName
        return cell
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
        TableViewOutlet.delegate=self
        TableViewOutlet.dataSource=self
        let p1=Product(productName: "MacBook Air", productDescription: "Laptop")
        productArray.append(p1)

        let p2=Product(productName: "iphone", productDescription: "Laptop")
        productArray.append(p2)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transiston=segue.identifier
        if transiston == "AppleProductDescription" {
            let destination = segue.destination as! ResultViewController
            destination.product = productArray[(TableViewOutlet.indexPathForSelectedRow?.row)!]
        }
    }

}

